import{V as t,f as r,ha as s}from"./chunk-POPYMCKD.js";function c(){let e;return t(s).onDestroy(()=>e?.unsubscribe()),b=>new r(i=>(e?.unsubscribe(),e=b.subscribe(i),e))}export{c as a};
