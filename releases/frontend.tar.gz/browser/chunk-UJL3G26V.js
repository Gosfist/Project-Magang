import{Z as t,f as r,la as s}from"./chunk-JSYTQ6C6.js";function c(){let e;return t(s).onDestroy(()=>e?.unsubscribe()),b=>new r(i=>(e?.unsubscribe(),e=b.subscribe(i),e))}export{c as a};
