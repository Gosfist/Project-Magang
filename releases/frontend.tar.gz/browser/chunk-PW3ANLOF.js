var o={production:!0,apiUrl:"/api",botWaUrl:"/api/wa"};export{o as a};
