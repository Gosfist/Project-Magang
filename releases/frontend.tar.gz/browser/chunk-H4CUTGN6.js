import{K as r,U as o,Z as s,f as n,ga as u}from"./chunk-EPWQ24UE.js";function c(t){t||(s(c),t=o(u));let i=new n(e=>t.onDestroy(e.next.bind(e)));return e=>e.pipe(r(i))}export{c as a};
