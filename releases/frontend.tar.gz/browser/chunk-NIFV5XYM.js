import{U as t,f as r,ga as s}from"./chunk-EPWQ24UE.js";function c(){let e;return t(s).onDestroy(()=>e?.unsubscribe()),b=>new r(i=>(e?.unsubscribe(),e=b.subscribe(i),e))}export{c as a};
