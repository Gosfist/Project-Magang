import{P as r,Z as o,ca as s,f as n,la as u}from"./chunk-JSYTQ6C6.js";function c(t){t||(s(c),t=o(u));let i=new n(e=>t.onDestroy(e.next.bind(e)));return e=>e.pipe(r(i))}export{c as a};
