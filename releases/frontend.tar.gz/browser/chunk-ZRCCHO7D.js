import{L as r,V as o,_ as s,f as n,ha as u}from"./chunk-KJ34ZB4F.js";function c(t){t||(s(c),t=o(u));let i=new n(e=>t.onDestroy(e.next.bind(e)));return e=>e.pipe(r(i))}export{c as a};
